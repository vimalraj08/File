const LEFT_KEY = 'ArrowLeft';
const UP_KEY = 'ArrowUp';
const RIGHT_KEY = 'ArrowRight';
const DOWN_KEY = 'ArrowDown';
  // 0,1,2,3
let grids = [
    [0,0,0,0], //0
    [0,0,0,0], //1
    [0,0,0,0], //2
    [0,0,0,0]  //3
];

function renderGridValues() {
    for (let i=0; i<4; i++) {
        for (let j=0; j<4; j++) {
            if (grids[i][j]) {
                let numberNode = document.createElement('div');
                numberNode.className = `gridNumber${grids[i][j]}`;
                numberNode.innerText = grids[i][j];
                let gridNode = document.getElementById(`${i}${j}`)
                gridNode.replaceChildren(numberNode);
            } else {
                let gridNode = document.getElementById(`${i}${j}`)
                gridNode.innerHTML = null;
            }
        }
    }
}

function start () {
    renderGridValues();
}

//step 1 : render 2 numbers on the grid

//step 2 : listen to keyboard events

//step 3 : distinguish between arrow keys



window.onload = start;
